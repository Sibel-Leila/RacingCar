#pragma once
#include <include/glm.h>


namespace Collision
{
	bool ColisionRoad(float sacXL, float sacXR);
	bool ColisionSaci(float sacXL, float sacXR, float sacZL, float sacZR);
};
