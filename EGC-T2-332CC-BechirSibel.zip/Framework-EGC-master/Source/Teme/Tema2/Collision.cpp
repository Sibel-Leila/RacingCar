#include "Collision.h"

#include <Core/Engine.h>

bool Collision::ColisionRoad(float sacXL, float sacXR) 
{
	return false;
}
bool Collision::ColisionSaci(float sacXL, float sacXR, float sacZL, float sacZR)
{
	return false;
}
