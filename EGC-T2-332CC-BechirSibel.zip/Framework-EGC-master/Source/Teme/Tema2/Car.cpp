#include "Car.h"

#include <Core/Engine.h>


Mesh* Car::Cube(std::string name, glm::vec3 leftBottomCorner, float x, float y, float z, glm::vec3 color, bool fill)
{
	glm::vec3 corner = leftBottomCorner;

	std::vector<VertexFormat> vertices = {
		VertexFormat(corner + glm::vec3(0, 0, z), color),
		VertexFormat(corner + glm::vec3(x, 0, z), color),
		VertexFormat(corner + glm::vec3(0, y, z), color),
		VertexFormat(corner + glm::vec3(x, y, z), color),
		VertexFormat(corner + glm::vec3(0, 0, 0), color),
		VertexFormat(corner + glm::vec3(x, 0, 0), color),
		VertexFormat(corner + glm::vec3(0, y, 0), color),
		VertexFormat(corner + glm::vec3(x, y, 0), color),
	};

	std::vector<unsigned short> indices =
	{
		0, 1, 2,
		1, 3, 2,
		2, 3, 7,
		2, 7, 6,
		1, 5, 7,
		6, 7, 4,
		7, 5, 4,
		0, 4, 1,
		1, 4, 5,
		2, 6, 4,
		0, 2, 4
	};

	Mesh* square = new Mesh(name);

	if (!fill) {
		square->SetDrawMode(GL_LINE_LOOP);
	}
	else {
		// draw 2 triangles. Add the remaining 2 indices
		indices.push_back(0);
		indices.push_back(2);
	}

	square->InitFromData(vertices, indices);
	return square;

}

Mesh* Car::Cube(std::string name, glm::vec3 leftBottomCorner, float x, float y, float z, bool fill)
{
	glm::vec3 corner = leftBottomCorner;

	std::vector<VertexFormat> vertices = {
		VertexFormat(corner + glm::vec3(0, 0, z), glm::vec3(0, 1, 1), glm::vec3(0.2, 0.8, 0.2)),
		VertexFormat(corner + glm::vec3(x, 0, z), glm::vec3(1, 0, 1), glm::vec3(0.9, 0.4, 0.2)),
		VertexFormat(corner + glm::vec3(0, y, z), glm::vec3(1, 0, 0), glm::vec3(0.7, 0.7, 0.1)),
		VertexFormat(corner + glm::vec3(x, y, z), glm::vec3(0, 1, 0), glm::vec3(0.7, 0.3, 0.7)),
		VertexFormat(corner + glm::vec3(0, 0, 0), glm::vec3(1, 1, 1), glm::vec3(0.3, 0.5, 0.4)),
		VertexFormat(corner + glm::vec3(x, 0, 0), glm::vec3(0, 1, 1), glm::vec3(0.5, 0.2, 0.9)),
		VertexFormat(corner + glm::vec3(0, y, 0), glm::vec3(1, 1, 0), glm::vec3(0.7, 0.0, 0.7)),
		VertexFormat(corner + glm::vec3(x, y, 0), glm::vec3(0, 0, 1), glm::vec3(0.1, 0.5, 0.8)),
	};

	std::vector<unsigned short> indices =
	{
		0, 1, 2,
		1, 3, 2,
		2, 3, 7,
		2, 7, 6,
		1, 5, 7,
		6, 7, 4,
		7, 5, 4,
		0, 4, 1,
		1, 4, 5,
		2, 6, 4,
		0, 2, 4
	};

	Mesh* square = new Mesh(name);

	if (!fill) {
		square->SetDrawMode(GL_LINE_LOOP);
	}
	else {
		// draw 2 triangles. Add the remaining 2 indices
		indices.push_back(0);
		indices.push_back(2);
	}

	square->InitFromData(vertices, indices);
	return square;

}

Mesh* Car::Tetra(std::string name, glm::vec3 leftBottomCorner, float x, float y, float z, bool fill)
{
	glm::vec3 corner = leftBottomCorner;

	std::vector<VertexFormat> vertices = {
		VertexFormat(corner + glm::vec3(x, 0, 0), glm::vec3(0.2, 0.7, 0.5)),
		VertexFormat(corner + glm::vec3(-x, 0, 0), glm::vec3(0.4, 0.5, 0.8)),
		VertexFormat(corner + glm::vec3(0, y, 0), glm::vec3(0.8, 0.7, 0.1)),
		VertexFormat(corner + glm::vec3(0, 0, z), glm::vec3(0.1, 0.5, 0.8)),
	};

	std::vector<unsigned short> indices =
	{
		0, 1, 2,
		0, 2, 3,
		0, 3, 1,
		2, 3, 1
	};

	Mesh* square = new Mesh(name);

	if (!fill) {
		square->SetDrawMode(GL_LINE_LOOP);
	}
	else {
		// draw 2 triangles. Add the remaining 2 indices
		indices.push_back(0);
		indices.push_back(2);
	}

	square->InitFromData(vertices, indices);
	return square;
}

Mesh* Car::Piramid(std::string name, glm::vec3 leftBottomCorner, float x, float y, float z, glm::vec3 color, bool fill)
{
	glm::vec3 corner = leftBottomCorner;

	std::vector<VertexFormat> vertices = {
		VertexFormat(corner + glm::vec3(0, 0, 0), color),
		VertexFormat(corner + glm::vec3(x, 0, 0), color),
		VertexFormat(corner + glm::vec3(x, 0, z), color),
		VertexFormat(corner + glm::vec3(0, 0, z), color),
		VertexFormat(corner + glm::vec3(0, y, z), color),
		VertexFormat(corner + glm::vec3(x, y, z), color),
	};

	std::vector<unsigned short> indices =
	{
		0, 1, 2,
		0, 2, 3,
		4, 5, 1,
		4, 1, 0,
		3, 4, 0,
		1, 5, 2
	};

	Mesh* square = new Mesh(name);

	if (!fill) {
		square->SetDrawMode(GL_LINE_LOOP);
	}
	else {
		// draw 2 triangles. Add the remaining 2 indices
		indices.push_back(0);
		indices.push_back(2);
	}

	square->InitFromData(vertices, indices);
	return square;
}

Mesh* Car::Road(std::string name, float y, float z, bool fill)
{
	std::vector<VertexFormat> vertices = {
		VertexFormat(glm::vec3(3, 0, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(3.5, 0, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(3.5, 0, z + 2), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(3, 0, z + 2), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(3, y, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(3.5, y, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(3.5, y, z + 2), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(3, y, z + 2), glm::vec3(0.4, 0.4, 0.4)),

		VertexFormat(glm::vec3(-3, 0, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-3.5, 0, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-3.5, 0, z + 2), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-3, 0, z + 2), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-3, y, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-3.5, y, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-3.5, y, z + 2), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-3, y, z + 2), glm::vec3(0.4, 0.4, 0.4)),

		VertexFormat(glm::vec3(3, 0.02, z), glm::vec3(0.25, 0.25, 0.25)),
		VertexFormat(glm::vec3(3, 0.02, z + 2), glm::vec3(0.25, 0.25, 0.25)),
		VertexFormat(glm::vec3(-3, 0.02, z + 2), glm::vec3(0.25, 0.25, 0.25)),
		VertexFormat(glm::vec3(-3, 0.02, z), glm::vec3(0.25, 0.25, 0.25)),
	};

	std::vector<unsigned short> indices =
	{
		0, 1, 2,   0, 2, 3,
		0, 1, 5,   0, 5, 4,
		1, 2, 6,   1, 6, 5,
		2, 3, 7,   2, 7, 6,
		3, 0, 4,   3, 4, 7,
		7, 4, 5,   7, 5, 6,

		8,  9, 10,    8, 10, 11,
		8,  9, 13,    8, 13, 12,
		9, 10, 14,    9, 14, 13,
		10, 11, 15,   10, 15, 14,
		11,  8, 12,   11, 12, 15,
		15, 12, 13,   15, 13, 14,

		16, 17, 18,    16, 18, 19
	};

	Mesh* square = new Mesh(name);

	if (!fill) {
		square->SetDrawMode(GL_LINE_LOOP);
	}
	else {
		// draw 2 triangles. Add the remaining 2 indices
		indices.push_back(0);
		indices.push_back(2);
	}

	square->InitFromData(vertices, indices);
	return square;
}

Mesh* Car::RoadRight(std::string name, float y, float z, bool fill)
{
	std::vector<VertexFormat> vertices = {
		VertexFormat(glm::vec3(3, 0, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(3.5, 0, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(2.5, 0, z + 2), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(2, 0, z + 2), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(3, y, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(3.5, y, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(2.5, y, z + 2), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(2, y, z + 2), glm::vec3(0.4, 0.4, 0.4)),

		VertexFormat(glm::vec3(-3, 0, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-3.5, 0, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-4.5, 0, z + 2), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-4, 0, z + 2), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-3, y, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-3.5, y, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-4.5, y, z + 2), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-4, y, z + 2), glm::vec3(0.4, 0.4, 0.4)),

		VertexFormat(glm::vec3(3, 0.02, z), glm::vec3(0.25, 0.25, 0.25)),
		VertexFormat(glm::vec3(2, 0.02, z + 2), glm::vec3(0.25, 0.25, 0.25)),
		VertexFormat(glm::vec3(-4, 0.02, z + 2), glm::vec3(0.25, 0.25, 0.25)),
		VertexFormat(glm::vec3(-3, 0.02, z), glm::vec3(0.25, 0.25, 0.25)),
	};

	std::vector<unsigned short> indices =
	{
		0, 1, 2,   0, 2, 3,
		0, 1, 5,   0, 5, 4,
		1, 2, 6,   1, 6, 5,
		2, 3, 7,   2, 7, 6,
		3, 0, 4,   3, 4, 7,
		7, 4, 5,   7, 5, 6,

		8,  9, 10,    8, 10, 11,
		8,  9, 13,    8, 13, 12,
		9, 10, 14,    9, 14, 13,
		10, 11, 15,   10, 15, 14,
		11,  8, 12,   11, 12, 15,
		15, 12, 13,   15, 13, 14,

		16, 17, 18,    16, 18, 19
	};

	Mesh* square = new Mesh(name);

	if (!fill) {
		square->SetDrawMode(GL_LINE_LOOP);
	}
	else {
		// draw 2 triangles. Add the remaining 2 indices
		indices.push_back(0);
		indices.push_back(2);
	}

	square->InitFromData(vertices, indices);
	return square;
}

Mesh* Car::RoadLeft(std::string name, float y, float z, bool fill)
{
	std::vector<VertexFormat> vertices = {
		VertexFormat(glm::vec3(3, 0, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(3.5, 0, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(4.5, 0, z + 2), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(4, 0, z + 2), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(3, y, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(3.5, y, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(4.5, y, z + 2), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(4, y, z + 2), glm::vec3(0.4, 0.4, 0.4)),

		VertexFormat(glm::vec3(-3, 0, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-3.5, 0, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-2.5, 0, z + 2), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-2, 0, z + 2), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-3, y, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-3.5, y, z), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-2.5, y, z + 2), glm::vec3(0.4, 0.4, 0.4)),
		VertexFormat(glm::vec3(-2, y, z + 2), glm::vec3(0.4, 0.4, 0.4)),

		VertexFormat(glm::vec3(3, 0.02, z), glm::vec3(0.25, 0.25, 0.25)),
		VertexFormat(glm::vec3(4.5, 0.02, z + 2), glm::vec3(0.25, 0.25, 0.25)),
		VertexFormat(glm::vec3(-2.5, 0.02, z + 2), glm::vec3(0.25, 0.25, 0.25)),
		VertexFormat(glm::vec3(-3, 0.02, z), glm::vec3(0.25, 0.25, 0.25)),
	};

	std::vector<unsigned short> indices =
	{
		0, 1, 2,   0, 2, 3,
		0, 1, 5,   0, 5, 4,
		1, 2, 6,   1, 6, 5,
		2, 3, 7,   2, 7, 6,
		3, 0, 4,   3, 4, 7,
		7, 4, 5,   7, 5, 6,

		8,  9, 10,    8, 10, 11,
		8,  9, 13,    8, 13, 12,
		9, 10, 14,    9, 14, 13,
		10, 11, 15,   10, 15, 14,
		11,  8, 12,   11, 12, 15,
		15, 12, 13,   15, 13, 14,

		16, 17, 18,    16, 18, 19
	};

	Mesh* square = new Mesh(name);

	if (!fill) {
		square->SetDrawMode(GL_LINE_LOOP);
	}
	else {
		// draw 2 triangles. Add the remaining 2 indices
		indices.push_back(0);
		indices.push_back(2);
	}

	square->InitFromData(vertices, indices);
	return square;
}