#pragma once

#include <string>

#include <include/glm.h>
#include <Core/GPU/Mesh.h>

namespace Car
{

	// Create square with given bottom left corner, length and color
	Mesh* Cube(std::string name, glm::vec3 leftBottomCorner, float x, float y, float z, glm::vec3 color, bool fill);
	Mesh* Cube(std::string name, glm::vec3 leftBottomCorner, float x, float y, float z, bool fill);
	Mesh* Piramid(std::string name, glm::vec3 leftBottomCorner, float x, float y, float z, glm::vec3 color, bool fill);
	Mesh* Tetra(std::string name, glm::vec3 leftBottomCorner, float x, float y, float z, bool fill);

	Mesh* Road(std::string name, float y, float z, bool fill);
	Mesh* RoadRight(std::string name, float y, float z, bool fill);
	Mesh* RoadLeft(std::string name, float y, float z, bool fill);
}