#include "Tema2.h"

#include <vector>
#include <string>
#include <iostream>
#include <random>

#include <Core/Engine.h>

using namespace std;

Tema2::Tema2()
{
}

Tema2::~Tema2()
{
}

void Tema2::Init()
{
	renderCameraTarget = false;

	camera = new Laborator::Tema2Camera();
	camera->Set(glm::vec3(0, 2, 3.5f), glm::vec3(0, 1, 0), glm::vec3(0, 1, 0));

	projectionMatrix = glm::perspective(RADIANS(60), window->props.aspectRatio, 0.01f, 200.0f);

	wire = false;

	fov = 60;
	modific = 2.0f;

	carX = -0.5;
	carY = 0.33;
	carZ = -1;
	
	sizeX = 1;
	sizeY = 0.5;
	sizeZ = 2;

	speed = 1;
	acceleration = 0;
	
	translateBara = 1; 
	flagBara = 1;

	curve = 0;
	translateX = 0;

	lives = 3;
	score = 0;
	endGame = 0;

	// Corp masina
	{
		Mesh* car = Car::Cube("car", glm::vec3(carX, carY, carZ), sizeX, sizeY, sizeZ, glm::vec3(1, 0, 1), true);
		AddMeshToList(car);

		Mesh* pir = Car::Piramid("pir", glm::vec3(carX + sizeX / 4 + 0.001, carY + sizeY + 0.001, carZ + sizeZ / 3 + 0.001), 0.5, 0.25, 1, glm::vec3(0, 0, 0.5), true);
		AddMeshToList(pir);
	}

	// Desenare sosea
	{
		// generare o harta random
		roadMid[0] = 0;
		roadMap[0] = 0;

		// generarea soselei folosind random
		for (int i = 1; i < 25; i++) {
			roadMap[i] = abs(std::rand() % 3);

			// translatia relativa fata de origine
			switch (roadMap[i]) {
			case 0: {
				roadMid[i] = roadMid[i - 1];
				break;
			}
			case 1: {
				roadMid[i] = roadMid[i - 1] - 1.5;
				break;
			}
			case 2: {
				roadMid[i] = roadMid[i - 1] + 1.5;
				break;
			}
			};
		}

		Mesh* road = Car::Road("road", 0.5, 0, true);
		AddMeshToList(road);

		Mesh* roadL = Car::RoadLeft("roadLeft", 0.5, 0, true);
		AddMeshToList(roadL);

		Mesh* roadR = Car::RoadRight("roadRight", 0.5, 0, true);
		AddMeshToList(roadR);
	}

	// Roti
	{
		Mesh* mesh = new Mesh("wheel_fl");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "mywheel.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}
	{
		Mesh* mesh = new Mesh("wheel_fr");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "mywheel.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}
	{
		Mesh* mesh = new Mesh("wheel_bl");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "mywheel.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}
	{
		Mesh* mesh = new Mesh("wheel_br");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "mywheel.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}
	
	// Crearea cerului
	{
		vector<VertexFormat> vertices
		{
			VertexFormat(glm::vec3(-100, -1,  100), glm::vec3(0, 0.5, 1), glm::vec3(0, 0, 0.75)),
			VertexFormat(glm::vec3( 100, -1,  100), glm::vec3(0, 0.5, 1), glm::vec3(0, 0, 0.75)),
			VertexFormat(glm::vec3(-100, 25,  100), glm::vec3(0, 0, 0.75), glm::vec3(0, 0.5, 1)),
			VertexFormat(glm::vec3( 100, 25,  100), glm::vec3(0, 0.5, 1), glm::vec3(0, 0, 0.75)),
			VertexFormat(glm::vec3(-100, -1, -100), glm::vec3(0, 0.5, 1), glm::vec3(0, 0, 0.75)),
			VertexFormat(glm::vec3( 100, -1, -100), glm::vec3(0, 0.5, 1), glm::vec3(0, 0, 0.75)),
			VertexFormat(glm::vec3(-100, 25, -100), glm::vec3(0, 0, 0.75), glm::vec3(0, 0.5, 1)),
			VertexFormat(glm::vec3( 100, 25, -100), glm::vec3(0, 0, 0.75), glm::vec3(0, 0.5, 1)),
			VertexFormat(glm::vec3(-100, -1,  100), glm::vec3(0, 0.5, 1), glm::vec3(0, 0, 0.75)),
		};

		vector<unsigned short> indices =
		{
			0, 1, 2,		1, 3, 2,
			2, 3, 7,		2, 7, 6,
			1, 7, 3,		1, 5, 7,
			6, 7, 4,		7, 5, 4,
			0, 4, 1,		1, 4, 5,
			2, 6, 4,		0, 2, 4,
		};

		CreateMesh("sky", vertices, indices);
	}

	// Crearea pamantului
	{
		vector<VertexFormat> vertices
		{
			VertexFormat(glm::vec3(-100, 0, 100), glm::vec3(0, 1, 0), glm::vec3(0, 0.8, 0)),
			VertexFormat(glm::vec3(100, 0, 100), glm::vec3(0, 1, 0), glm::vec3(0, 0.4, 0)),
			VertexFormat(glm::vec3(100, 0, -100), glm::vec3(0, 1, 0), glm::vec3(0, 0.2, 0)),
			VertexFormat(glm::vec3(-100, 0, -100), glm::vec3(0, 1, 0), glm::vec3(0, 0.5, 0)),
		};

		vector<unsigned short> indices =
		{
			0, 1, 2,		0, 2, 3
		};

		CreateMesh("grass", vertices, indices);
	}

	// Create a shader program for drawing face polygon with the color of the normal
	{
		Shader *shader = new Shader("myShader");
		shader->AddShader("Source/Teme/Tema2/Shaders/VertexShader.glsl", GL_VERTEX_SHADER);
		shader->AddShader("Source/Teme/Tema2/Shaders/FragmentShader.glsl", GL_FRAGMENT_SHADER);
		shader->CreateAndLink();
		shaders[shader->GetName()] = shader;
	}

	// Desenarea obstacolelor
	{
		Mesh* mesh = new Mesh("cylinder");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "mywheel.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}
	{
		Mesh* mesh = new Mesh("stalp");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "stalpi.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}
	{
		Mesh* mesh = new Mesh("bara");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "stalpi.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}
	{

		Mesh* mesh = new Mesh("saci");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "sacii.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}
	{

		Mesh* mesh = new Mesh("piramida");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "piramida.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}
}

Mesh* Tema2::CreateMesh(const char *name, const std::vector<VertexFormat> &vertices, const std::vector<unsigned short> &indices)
{
	unsigned int VAO = 0;
	// Create the VAO and bind it
	glGenVertexArrays(1, &VAO);
	glBindVertexArray(VAO);

	// Create the VBO and bind it
	unsigned int VBO;
	glGenBuffers(1, &VBO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);

	// Send vertices data into the VBO buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices[0]) * vertices.size(), &vertices[0], GL_STATIC_DRAW);

	// Crete the IBO and bind it
	unsigned int IBO;
	glGenBuffers(1, &IBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);

	// TODO: Send indices data into the IBO buffer
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices[0]) * indices.size(), &indices[0], GL_STATIC_DRAW);

	// ========================================================================
	// This section describes how the GPU Shader Vertex Shader program receives data

	// set vertex position attribute
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), 0);

	// set vertex normal attribute
	glEnableVertexAttribArray(3);
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)(sizeof(glm::vec3)));

	// set texture coordinate attribute
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)(2 * sizeof(glm::vec3)));

	// set vertex color attribute
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)(2 * sizeof(glm::vec3) + sizeof(glm::vec2)));
	// ========================================================================

	// Unbind the VAO
	glBindVertexArray(0);

	// Check for OpenGL errors
	CheckOpenGLError();

	// Mesh information is saved into a Mesh object
	meshes[name] = new Mesh(name);
	meshes[name]->InitFromBuffer(VAO, static_cast<unsigned short>(indices.size()));
	meshes[name]->vertices = vertices;
	meshes[name]->indices = indices;
	return meshes[name];
}

void Tema2::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void Tema2::Update(float deltaTimeSeconds)
{
	if (wire)
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	else
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);


	// finalul traseului
	if (speed / 100 > 48 && endGame == 0) {
		endGame = 1;
	}

	// nu mai am vieti
	if (lives == 0 && endGame == 0) {
		cout << "Nu mai ai vieti" << endl;
		endGame = 2;
	}
	// actualizare scor
	if (endGame == 0 || lives > 0) {
		score += speed / 100;
	}

	// afisarea scorului
	if (endGame == 1) {
		cout << "End Game\n\tYour score is: " << score << endl;
		endGame = 2;
	}

	// Coliziuni
	{
		// Part 1 -> Coliziuni cu soseaua
		int nrRoad = (int) speed / 200;
		int carCentre = translateX + carX;

		switch (roadMap[nrRoad]) {
		case 0: {
			// colixziune pe x
			if (-3 + roadMap[nrRoad] >= carCentre - sizeX / 2 + 0.5) {		// 0.5 este dimansiunea rotii 
				lives--;
				if (lives > 0)
					cout << "Mai ai " << lives << " vieti :(" << endl;
				translateX += deltaTimeSeconds * 10;
			}

			if (carCentre + sizeX + 0.5 >= 3 + roadMap[nrRoad]) {
				lives--;
				if (lives > 0)
					cout << "Mai ai " << lives << " vieti :(" << endl;
				translateX -= deltaTimeSeconds * 10;
			}
			break;
		}
		case 1: {
			// colixziune pe x
			if (-2 + roadMap[nrRoad] >= carCentre - sizeX / 2 + 0.5) {
				lives--;
				if (lives > 0)
					cout << "Mai ai " << lives << " vieti :(" << endl;
				translateX += deltaTimeSeconds * 10;
			}

			if (carCentre + sizeX + 0.5 >= 3 + roadMap[nrRoad]) {
				lives--;
				if (lives > 0)
					cout << "Mai ai " << lives << " vieti :(" << endl;
				translateX -= deltaTimeSeconds * 10;
			}
			break;
		}
		case 2: {
			if (-3 + roadMap[nrRoad] >= carCentre - sizeX / 2 + 0.5) {
				lives--;
				if (lives > 0)
					cout << "Mai ai " << lives << " vieti :(" << endl;
				translateX += deltaTimeSeconds * 10;
			}

			if (carCentre + sizeX + 0.5 >= 2 + roadMap[nrRoad]) {
				lives--;
				if (lives > 0)
					cout << "Mai ai " << lives << " vieti :(" << endl;
				translateX -= deltaTimeSeconds * 10;
			}
			break;
		}
		};

		/*
		// Part 2 -> Coliziuni cu obstacolele
		// Stapul
		{
			float zmax, zmin, xmax, xmin;
			zmax = speed / 100 - 5.2;
			zmin = speed / 100 - 4.8;

			xmax = roadMid[2] / 4 + 0.2;
			xmin = roadMid[2] / 4 - 0.2;

			if (xmin < carCentre - 0.5 && carCentre + 0.5 < xmax  &&
				zmin < carCentre - 1  && carCentre + sizeZ < zmax + 1) {		// 0.5 este dimansiunea rotii 
				lives--;
				cout << "Mai ai " << lives << " vieti :(" << endl;
				translateX += deltaTimeSeconds * 10;
			}
		}
		*/

	}

	// Randeaza roti
	{
		modelMatrix = glm::mat4(1);
		modelMatrix = Transform::Translate(translateX, 0, 0) *
			Transform::RotateOY(RADIANS(curve)) *
			Transform::Translate(carX, carY, carZ) *
			Transform::RotateOZ(RADIANS(-speed)) *
			Transform::RotateOY(RADIANS(90)) *
			Transform::Scale(0.35, 0.35, 0.35) *
			modelMatrix;
		RenderMesh(meshes["wheel_fl"], shaders["VertexNormal"], modelMatrix);

		modelMatrix = glm::mat4(1);
		modelMatrix = Transform::Translate(translateX, 0, 0) *
			Transform::RotateOY(RADIANS(curve)) *
			Transform::Translate(carX + sizeX, carY, carZ) *
			Transform::RotateOZ(RADIANS(-speed)) *
			Transform::RotateOY(RADIANS(90)) *
			Transform::Scale(0.35, 0.35, 0.35) *
			modelMatrix;
		RenderMesh(meshes["wheel_fr"], shaders["VertexNormal"], modelMatrix);

		modelMatrix = glm::mat4(1);
		modelMatrix = Transform::Translate(translateX, 0, 0) *
			Transform::RotateOY(RADIANS(curve)) *
			Transform::Translate(carX + sizeX, carY, carZ + sizeZ) *
			Transform::RotateOZ(RADIANS(-speed)) *
			Transform::RotateOY(RADIANS(90)) *
			Transform::Scale(0.35, 0.35, 0.35) *
			modelMatrix;
		RenderMesh(meshes["wheel_fl"], shaders["VertexNormal"], modelMatrix);

		modelMatrix = glm::mat4(1);
		modelMatrix = Transform::Translate(translateX, 0, 0) *
			Transform::RotateOY(RADIANS(curve)) *
			Transform::Translate(carX, carY, carZ + sizeZ)  *
			Transform::RotateOZ(RADIANS(-speed)) *
			Transform::RotateOY(RADIANS(90)) *
			Transform::Scale(0.35, 0.35, 0.35) *
			modelMatrix;
		RenderMesh(meshes["wheel_fr"], shaders["VertexNormal"], modelMatrix);
	}

	// Randeaza corpul masinii
	{
		modelMatrix = glm::mat4(1);
		modelMatrix = Transform::Translate(translateX, 0, 0) *
			Transform::Translate(carX + sizeX / 2, carY - sizeY / 2, carZ + sizeZ / 2)  *
			Transform::RotateOY(RADIANS(curve)) *
			Transform::Translate(0, 0, 0)  *
			modelMatrix;
		RenderMesh(meshes["car"], shaders["VertexColor"], modelMatrix);
		RenderMesh(meshes["pir"], shaders["VertexColor"], modelMatrix);
	}

	// Randeaza cerul si pamantul
	{
		modelMatrix = glm::mat4(1);
		RenderSimpleMesh(meshes["sky"], shaders["myShader"], modelMatrix, glm::vec3(0, 0, 0.75), glm::vec3(1, 0.25, 0));
		RenderMesh(meshes["grass"], shaders["VertexColor"], modelMatrix);
	}

	// Randeaza soseaua
	{
		modelMatrix = glm::mat4(1);
		modelMatrix *= Transform::Translate(0, 0, speed / 100);

		for (int i = 0; i < 25; i++) {
			switch (roadMap[i]) {
			case 0: {
				RenderMesh(meshes["road"], shaders["VertexColor"], modelMatrix);
				break;
			}
			case 1: {
				modelMatrix *= Transform::Translate(-1, 0, 0);
				RenderMesh(meshes["roadLeft"], shaders["VertexColor"], modelMatrix);
				break;
			}
			case 2: {
				modelMatrix *= Transform::Translate(1, 0, 0);
				RenderMesh(meshes["roadRight"], shaders["VertexColor"], modelMatrix);
				break;
			}
			};
			modelMatrix *= Transform::Translate(0, 0, -2);

		}
	}

	// Randeaza obstacolele
	{
		modelMatrix = glm::mat4(1);
		modelMatrix = Transform::Translate(roadMid[2] / 4, 0, speed / 100 - 5) *
			Transform::Scale(0.2, 0.2, 0.2) *
			modelMatrix;
		RenderMesh(meshes["stalp"], shaders["VertexNormal"], modelMatrix);

		modelMatrix = glm::mat4(1);
		modelMatrix = Transform::Translate(roadMid[4] * 2 / 3, 0, speed / 100 - 8.5) *
		Transform::RotateOY(RADIANS(-90)) *
		Transform::Scale(0.2, 0.2, 0.2) *
		Transform::Translate(0, 0, 0) *
		modelMatrix;
			modelMatrix;
		RenderMesh(meshes["saci"], shaders["VertexNormal"], modelMatrix);

		modelMatrix = glm::mat4(1);
		modelMatrix = Transform::Translate(roadMid[7] / 3, 0, speed / 100 - 15) *
			Transform::Scale(0.2, 0.2, 0.2) *
			modelMatrix;			
		RenderMesh(meshes["piramida"], shaders["VertexNormal"], modelMatrix);

		modelMatrix = glm::mat4(1);
		modelMatrix = Transform::Translate(roadMid[11], 0, speed / 100 - 23) *
			Transform::RotateOZ(RADIANS(90)) *
			Transform::Scale(0.25, 0.15, 5) *
			modelMatrix;
		RenderMesh(meshes["cylinder"], shaders["VertexNormal"], modelMatrix);
			
		if (translateBara > 2)
			flagBara = -1;
		if (translateBara < 0.5)
			flagBara = 1;

		translateBara += flagBara * deltaTimeSeconds; 
			
		modelMatrix = glm::mat4(1);
		modelMatrix = Transform::Translate(roadMid[20] + 1, translateBara, speed / 100 - 41) *
			Transform::RotateOX(RADIANS(90)) *
			Transform::RotateOY(RADIANS(-90)) *
			Transform::Scale(1 / translateBara, 1, 1) *
			Transform::Translate(0, -1, 0) *
			modelMatrix;
		RenderMesh(meshes["bara"], shaders["VertexNormal"], modelMatrix);
	}
}

void Tema2::FrameEnd()
{
	// DrawCoordinatSystem(camera->GetViewMatrix(), projectionMatrix);
}

void Tema2::RenderMesh(Mesh * mesh, Shader * shader, const glm::mat4 & modelMatrix)
{
	if (!mesh || !shader)
		return;

	// render an object using the specified shader and the specified position
	shader->Use();
	glUniformMatrix4fv(shader->loc_view_matrix, 1, false, glm::value_ptr(camera->GetViewMatrix()));
	glUniformMatrix4fv(shader->loc_projection_matrix, 1, false, glm::value_ptr(projectionMatrix));
	glUniformMatrix4fv(shader->loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	mesh->Render();
}

void Tema2::RenderSimpleMesh(Mesh *mesh, Shader *shader, const glm::mat4 & modelMatrix, glm::vec3 color1, glm::vec3 color2)
{
	if (!mesh || !shader || !shader->GetProgramID())
		return;

	glUseProgram(shader->program);

	int location1 = glGetUniformLocation(shader->program, "Model");
	glUniformMatrix4fv(location1, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	int location2 = glGetUniformLocation(shader->program, "View");

	glm::mat4 viewMatrix = GetSceneCamera()->GetViewMatrix();
	glUniformMatrix4fv(location2, 1, GL_FALSE, glm::value_ptr(viewMatrix));

	int location3 = glGetUniformLocation(shader->program, "Projection");

	glm::mat4 projectionMatrix = GetSceneCamera()->GetProjectionMatrix();
	glUniformMatrix4fv(location3, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

	float time = Engine::GetElapsedTime();
	int time_location = glGetUniformLocation(shader->program, "time");
	glUniform1f(time_location, time);

	int dayNight_location = glGetUniformLocation(shader->program, "dayNight");
	glUniform1f(dayNight_location, (int) time % 100);

	int color1_location = glGetUniformLocation(shader->program, "color1");
	glUniform3fv(color1_location, 1, glm::value_ptr(color1));

	int color2_location = glGetUniformLocation(shader->program, "color2");
	glUniform3fv(color2_location, 1, glm::value_ptr(color2));

	glBindVertexArray(mesh->GetBuffers()->VAO);
	glDrawElements(mesh->GetDrawMode(), static_cast<int>(mesh->indices.size()), GL_UNSIGNED_SHORT, 0);
}

void Tema2::OnInputUpdate(float deltaTime, int mods)
{
	if (endGame == 0) {
		// move the camera only if MOUSE_RIGHT button is pressed
		if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
		{
			float cameraSpeed = 2.0f;

			if (window->KeyHold(GLFW_KEY_W)) {
				camera->TranslateForward(deltaTime * cameraSpeed);
			}

			if (window->KeyHold(GLFW_KEY_A)) {
				camera->TranslateRight(-deltaTime * cameraSpeed);
			}

			if (window->KeyHold(GLFW_KEY_S)) {
				camera->TranslateForward(-deltaTime * cameraSpeed);
			}

			if (window->KeyHold(GLFW_KEY_D)) {
				camera->TranslateRight(deltaTime * cameraSpeed);
			}

			if (window->KeyHold(GLFW_KEY_Q)) {
				camera->TranslateUpword(-deltaTime * cameraSpeed);
			}

			if (window->KeyHold(GLFW_KEY_E)) {
				camera->TranslateUpword(deltaTime * cameraSpeed);
			}

			if (window->KeyHold(GLFW_KEY_U)) {
				fov += 1;
				projectionMatrix = glm::perspective(RADIANS(fov), window->props.aspectRatio, 0.01f, 200.0f);
			}

			if (window->KeyHold(GLFW_KEY_I)) {
				fov -= 1;
				projectionMatrix = glm::perspective(RADIANS(fov), window->props.aspectRatio, 0.01f, 200.0f);
			}

			if (window->KeyHold(GLFW_KEY_G)) {
				modific += 2;
				projectionMatrix = glm::ortho(-modific, modific, -modific, modific, -modific, modific);
			}

			if (window->KeyHold(GLFW_KEY_H)) {
				modific -= 2;
				projectionMatrix = glm::ortho(-modific, modific, -modific, modific, -modific, modific);
			}
		}

		// ajustarea vitezei
		if (window->KeyHold(GLFW_KEY_UP)) {		// accelerare
			acceleration += deltaTime;
		}
		if (window->KeyHold(GLFW_KEY_DOWN)) {	// decelerare
			acceleration -= deltaTime;
		}

		speed += acceleration;

		// curbei
		if (window->KeyHold(GLFW_KEY_RIGHT)) {
			curve += deltaTime;
			translateX += deltaTime;
			camera->TranslateRight(deltaTime);
		}

		if (window->KeyHold(GLFW_KEY_LEFT)) {
			curve -= deltaTime;
			translateX -= deltaTime;
			camera->TranslateRight(-deltaTime);
		}
	}
}

void Tema2::OnKeyPress(int key, int mods)
{
	// add key press event
	if (key == GLFW_KEY_T)
	{
		renderCameraTarget = !renderCameraTarget;
	}

	// first person
	if (window->KeyHold(GLFW_KEY_O)) {
		projectionMatrix = glm::ortho(-1.f, 1.f, 0.f, 3.f, 1.f, 100.f);
	}

	// third person
	if (window->KeyHold(GLFW_KEY_P)) {
		projectionMatrix = glm::perspective(RADIANS(60), window->props.aspectRatio, 0.01f, 200.0f);
	}

	// third person
	if (window->KeyHold(GLFW_KEY_1)) {
		wire = true;
	}
	// third person
	if (window->KeyHold(GLFW_KEY_2)) {
		wire = false;
	}
}

void Tema2::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void Tema2::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event

	if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
	{
		float sensivityOX = 0.001f;
		float sensivityOY = 0.001f;

		if (window->GetSpecialKeyState() == 0) {
			renderCameraTarget = false;
			// Rotate the camera in First-person mode around OX and OY using deltaX and deltaY
			// use the sensitivity variables for setting up the rotation speed
			camera->RotateFirstPerson_OX(sensivityOX * deltaY);
			camera->RotateFirstPerson_OY(sensivityOY * deltaX);
		}

		if (window->GetSpecialKeyState() && GLFW_MOD_CONTROL) {
			renderCameraTarget = true;
			// Rotate the camera in Third-person mode around OX and OY using deltaX and deltaY
			// use the sensitivity variables for setting up the rotation speed
			camera->RotateFirstPerson_OX(sensivityOX * deltaY);
			camera->RotateFirstPerson_OY(sensivityOY * deltaX);
		}
	}
}

void Tema2::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void Tema2::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void Tema2::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Tema2::OnWindowResize(int width, int height)
{
}
